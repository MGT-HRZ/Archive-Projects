<?php get_header()?>

<header class="top">
        <div class="title">
            <table width="20%">
                <tr>
                    <td width="15%">
                        <center>
                            <a href="index.html"><img src="img/logo.png" id="logo"></a>
                        </center>
                    </td>
                    <td width="5%"><a href="index.html" id="link-title">JOURNEY</a></td>
                </tr>
            </table>
        </div>
        <nav>
            <ul>
                <li><a href="index.html"><span id="point_home">Home</span></a></li>
                <li><a href="#">Top Destinations</a></li>
                <li><a href="#">Recommended Places</a></li>
                <li><a href="#">Contact us</a></li>
            </ul>
        </nav>
    </header>
    <section>
        <div class="image_bckgrd">
            <center>
            <p id="txt1">LET'S BEGIN</p>
            <p><img src="img/dots-3.png" id="dots"></p>
            <p id="txt2">We assist you to choose the best.</p>
            <p><a href="#"><img src="img/down-btn.png" id="dwn-btn"></a></p>
            <div class="form1">
                <form action="">
                    <p id="txt3"><label>Choose Your Destination</label></p>
                    <p id="input1"><input type="text" placeholder="Type your destination..."></p>

                    <p id="txt4"><label>Check In Date</label></p>
                    <p id="input2"><input type="text" placeholder="Check In"></p>

                    <p id="txt5"><label>Check Out Date</label></p>
                    <p id="input3"><input type="text" placeholder="Check Out"></p>

                    <p id="txt6"><label>How many rooms?</label></p>
                    <p id="input4">
                        <select name="room" id="room-list">
                            <option>1 Room</option>
                            <option>2 Room</option>
                            <option>3 Room</option>
                            <option>4 Room</option>
                        </select>
                    </p>

                    <p id="txt7"><label>Adult</label></p>
                    <p id="input5">
                        <select name="adult" id="adult-list">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                        </select>
                    </p>

                    <p id="txt8"><label>Children</label></p>
                    <p id="input6">
                        <select name="children" id="child-list">
                            <option>0</option>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                            <option>7</option>
                        </select>
                    </p>

                    <button id="chk-btn" type="submit">CHECK AVAILABILITY</button>
                </form>
            </div>
            </center>
        </div>
    </section>
    <section class="bg-color1">
        <center>
        <div class="explore">
            <p id="title2">YOUR <span id="txt-bold1">JOURNEY</span> IS OUR PRIORITY</p>

            <p id="txt9">Nullam auctor, sapien sit amet lacinia euismod, lorem magna lobortis massa, in tincidunt mi metus quis lectus. Duis nec lobortis velit. Vivamus id magna vulputate, tempor ante eget, tempus augue. Maecenas ultricies neque magna.</p>
            
            <p id="space1"><button id="explr-btn">CONTINUE EXPLORE</button></p>
        </div>
        </center>
    </section>
    <section class="bg-color2">
        <p><h2>Latest Posts</h2></p>
        <div class="slot1">
            <div id="txt10">
            <?php if(have_posts()) : while (have_posts()) : the_post();?>
                <h1><?php the_title()?></h1>
                <h4>Post <?php the_time('s')?>, posted on <?php the_time('j F Y')?></h4>
                <hr>
                <p><?php the_content(__('(more...)'));?></p>
                <hr>
            <?php endwhile; else: ?>
                <p><?php _e('Sorry, no posts matched your criteria.')?></p>
            <?php endif;?>
            </div>
        </div>
        <?php get_sidebar()?>
    </section>
    <section>
        <div class="slot3"><br></div>
    </section>

<?php get_footer()?>
